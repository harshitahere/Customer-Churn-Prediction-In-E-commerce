Customer Churn Prediction In E-commerce

Project Overview
Customer churn is a major business challenge, as retaining existing customers is more cost-effective than acquiring new ones. This capstone project focuses on predicting customer churn using machine learning techniques by analyzing customer demographics, service usage, and account-related information.

The project demonstrates a complete end-to-end data science workflow, covering Exploratory Data Analysis (EDA), data preprocessing and feature engineering, and model training with evaluation and comparison.

Business Objective
The primary objective of this project is to identify customers who are likely to churn so that businesses can take proactive retention actions. By improving churn prediction accuracy, the project aims to support data-driven decision-making and reduce potential revenue loss.


Dataset Summary
Column Meaning Explanation
1️⃣ Age
Customer’s age in years.
2️⃣ Gender
Customer’s gender (Male / Female / Other).
3️⃣ Country
Country where the customer resides.
4️⃣ City
City of the customer.
5️⃣ Membership_Years
Number of years the customer has been registered on the platform.
6️⃣ Login_Frequency
How often the customer logs into the platform (number of logins in a given time period).
7️⃣ Session_Duration_Avg
Average time (in minutes) a customer spends per session.
8️⃣ Pages_Per_Session
Average number of pages viewed per visit.
9️⃣ Cart_Abandonment_Rate
Percentage of times a customer adds items to cart but does not complete the purchase.
🔟 Wishlist_Items
Number of items the customer has added to their wishlist.
1️⃣1️⃣ Total_Purchases
Total number of completed purchases made by the customer.
1️⃣2️⃣ Average_Order_Value
Average monetary value spent per order.
1️⃣3️⃣ Days_Since_Last_Purchase
Number of days since the customer last made a purchase.
1️⃣4️⃣ Discount_Usage_Rate
Percentage of purchases where the customer used a discount or coupon.
1️⃣5️⃣ Returns_Rate
Percentage of orders returned by the customer.
1️⃣6️⃣ Email_Open_Rate
Percentage of marketing emails opened by the customer.
1️⃣7️⃣ Customer_Service_Calls
Number of times the customer contacted customer support.
1️⃣8️⃣ Product_Reviews_Written
Number of product reviews written by the customer.
1️⃣9️⃣ Social_Media_Engagement_Score
Score representing how much the customer interacts with the brand on social media.
2️⃣0️⃣ Mobile_App_Usage
Measure of how actively the customer uses the mobile application.
2️⃣1️⃣ Payment_Method_Diversity
Number of different payment methods used by the customer (e.g., credit card, UPI, PayPal, etc.).
2️⃣2️⃣ Lifetime_Value
Total revenue generated from the customer since signup.
2️⃣3️⃣ Credit_Balance
Remaining store credit or wallet balance of the customer.
2️⃣4️⃣ Churned
Target variable:
1 = Customer stopped using the platform
0 = Customer is still active
2️⃣5️⃣ Signup_Quarter
Quarter of the year in which the customer signed up (Q1, Q2, Q3, Q4).
Project Structure
The project is organized into the following notebooks:

EDA.ipynb: Exploratory Data Analysis

Data_Preprocessing.ipynb: Data cleaning, encoding, and feature preparation

Model_Training.ipynb: Model development, tuning, and evaluation

Exploratory Data Analysis (EDA)
The EDA phase focuses on understanding the dataset and identifying patterns related to customer churn. Key activities include analyzing customer demographics, service usage behavior, and churn distribution. Visualizations and summary statistics are used to identify trends and class imbalance.

Key insights from EDA indicate that churn customers exhibit distinct behavioral patterns, particularly in tenure, billing behavior, and service usage. The presence of class imbalance highlights the need for careful model evaluation, especially for recall-focused metrics.

Data Preprocessing and Feature Engineering
The preprocessing phase prepares the data for machine learning by handling missing values, encoding categorical variables, and scaling numerical features. Proper train-test separation is maintained throughout the process to prevent data leakage.

As a result, the dataset becomes clean, consistent, and suitable for model training, improving both model stability and predictive performance.

Model Training and Evaluation
Multiple machine learning models are trained and evaluated to compare performance and identify the most effective approach for churn prediction. The following models are implemented:

Logistic Regression (baseline, balanced, and tuned)

Random Forest

AdaBoost

Gradient Boosting (tuned)

Models are evaluated using accuracy, precision, recall, F1-score, and confusion matrices. Special emphasis is placed on recall and F1-score due to the business importance of correctly identifying churn customers.

Best Model Result
Among all trained models, Tuned Gradient Boosting delivers the best overall performance. It achieves a strong balance between precision and recall and demonstrates superior ability to identify churn customers while minimizing false negatives. This makes it the most suitable model for real-world churn prediction scenarios.

Model Comparison Summary
Logistic Regression serves as a strong and interpretable baseline model. It shows moderate performance but is sensitive to data complexity. Random Forest performs well and provides robust results but is slightly outperformed by Gradient Boosting. AdaBoost improves predictions by focusing on misclassified churn cases. Overall, ensemble models outperform simpler approaches.

Key Business Insight
Tuned Gradient Boosting provides the most reliable churn predictions, enabling early identification of at-risk customers and supporting effective, data-driven retention strategies.

Tools and Technologies
Python
Pandas, NumPy
Matplotlib, Seaborn
Scikit-learn
Jupyter Notebook